#ifndef UTILS_H
#define UTILS_H
void checkMalloc(void *data);
void checkFile(FILE *file);
#endif